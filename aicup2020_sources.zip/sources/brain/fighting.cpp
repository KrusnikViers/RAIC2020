#include "brain/fighting.h"

void FightingPlanner::update(const PlayerView& view, State& state) {}

EntityAction FightingPlanner::command(const Entity* entity) {
  return EntityAction();
}
