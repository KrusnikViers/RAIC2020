#include "brain/building_queue.h"

void BuildingQueue::update(const PlayerView& view, const State& state) {}

void BuildingQueue::enqueue(EntityType type, const State* state) {}

EntityAction BuildingQueue::commandsForBuilder(const Entity* entity) {
  return EntityAction();
}