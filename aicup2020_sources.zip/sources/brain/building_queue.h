#pragma once

#include <queue>

#include "brain/state.h"
#include "model/Model.hpp"

class BuildingQueue {
 public:
  BuildingQueue() = default;

  struct EnqueuedStructure {
    Vec2Int pos;
    EntityType type;
    int builder_id = -1;
  };

  void update(const PlayerView& view, const State& state);
  void enqueue(EntityType type, const State* state);
  EntityAction commandsForBuilder(const Entity* entity);

 private:
  std::shared_ptr<EnqueuedStructure> waiting;
  std::unordered_map<int, EnqueuedStructure> building;
};
